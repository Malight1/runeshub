import React,{useEffect, useRef, useState} from 'react'
import {AiOutlineClose} from "react-icons/ai"
import logo from "./assets/logo.png"
import { LuMenu } from "react-icons/lu";
import "./home.css"
import { FaTelegram , FaTwitter} from "react-icons/fa";
import { GiWhiteBook } from "react-icons/gi";
import logs from "./assets/logs.png"


const Sidebar = ({
    showSidebar,
    toggleSidebar,

}) => {
    const sidebarRef = useRef(null);
    const [viewportWidth, setViewportWidth] = useState(window.innerWidth);

    useEffect(() => {
        const handleResize = () => {
            setViewportWidth(window.innerWidth);
        };

        window.addEventListener('resize', handleResize);

        return () => {
            window.removeEventListener('resize', handleResize);
        };
    }, []);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (showSidebar && sidebarRef.current && viewportWidth <= 745) {
                if (!sidebarRef.current.contains(event.target)) {
                    toggleSidebar(false);
                }
            }
        };

        document.addEventListener("mousedown", handleClickOutside);

        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [showSidebar, toggleSidebar, viewportWidth]);
    return (
        <div
            ref={sidebarRef}
            className={showSidebar ? "sidebar" : "sidebar closed"}
        >
            <div className="side_top">
                <div className="men" onClick={toggleSidebar}>
                    {showSidebar ?<AiOutlineClose  className='icon' /> :<LuMenu className='icon'  /> }
                    
                </div>
                {showSidebar ? <img className="logo" src={logo} alt="Logo" /> : <img className="log" src={logs} alt="Logo" />}
                
               {showSidebar &&   <p>Bridge</p>}
            {showSidebar && <span>Stake RHUB</span>}
                
            </div>
            <div className="side_bottom">
                <a target='_blank' href="https://t.me/runeshub"><FaTelegram /> {showSidebar && "TELEGRAM" } </a>
                <a target='_blank' href="https://x.com/runeshuberc"><FaTwitter />{showSidebar && "TWITTER" }  </a>
                <a target='_blank' href="https://runeshub.gitbook.io/documentation/"><GiWhiteBook />{showSidebar && "WHITEPAPER" }  </a>
            </div>

        </div>
    );
};

export default Sidebar;