import React from 'react'
import confirm from "./assets/confirm.png"
import "./home.css";
import { Link } from 'react-router-dom';


const Confirm = () => {
  return (
    
    <div className="home">
         <div className="home_btn">
        <Link target='_blank' to="http://www.runeshub.org/">Home</Link>
      </div>
      <div className="confirm main">
    <img src={confirm} alt="" />
    <p>Your Transaction has been sent</p>
    <span>Your Preferred coin will arrive in your wallet in a few.</span>
      </div>
    </div>
  )
}

export default Confirm