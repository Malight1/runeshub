import { useState } from 'react'
import './App.css'
import Home from './Home'
import Sidebar from './Sidebar';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Confirm from './Confirm';

function App() {

  const [showSidebar, setShowSidebar] = useState(window.innerWidth >= 650);

  const toggleSidebar = () => {
    setShowSidebar(!showSidebar);

  };

  return (
    <BrowserRouter>
      <div className="app">
        <ToastContainer></ToastContainer>
        <div className="layout">
          <div className="cide">
            <Sidebar
              showSidebar={showSidebar}
              toggleSidebar={toggleSidebar}
            />
          </div>
          <div className={showSidebar ? "component" : "close-side"}>
            <Routes>
              <Route index element={<Home />} />
              <Route path='/confirm' element={<Confirm />} />
            </Routes>

          </div>
        </div>

      </div>
    </BrowserRouter>


  )
}

export default App
